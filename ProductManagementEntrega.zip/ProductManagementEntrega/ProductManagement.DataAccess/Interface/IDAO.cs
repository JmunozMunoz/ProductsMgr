﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.DataAccess.Interface
{
    interface IDao<Template>
    {
        void Create(Template obj);
        void Update(Template obj);
        void Delete(Template obj);
        Template FindID(int ID);
        List<Template> FindAll();
    }

}
