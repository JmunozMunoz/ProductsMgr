﻿using System;
using System.Collections.Generic;
using ProductManagement.DataAccess.Interface;
using ProductManagement.Entities.Models;
using System.Data.SqlClient;
using System.Data;

namespace ProductManagement.DataAccess.DAO
{
    public class CategoryDAO : DataBaseConnection, IDao<CategoryModel>
    {
        public void Create(CategoryModel category)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementCategories, "Categories");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = category.Description;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeInsert;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public void Delete(CategoryModel category)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementCategories, "Categories");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = category.CategoryID;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = category.Description;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeDelete;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public List<CategoryModel> FindAll()
        {
            List<CategoryModel> categories = new List<CategoryModel>();

            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementCategories, "Categories");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelect;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    CategoryModel category = new CategoryModel
                    (
                        Convert.ToInt32(read["categoryID"].ToString()),
                        Convert.ToString(read["description"].ToString())
                    );

                    categories.Add(category);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return categories;
        }

        public CategoryModel FindID(int ID)
        {
            CategoryModel category = new CategoryModel();

            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementCategories, "Categories");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = ID;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelectID;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    category = new CategoryModel
                    (
                        Convert.ToInt32(read["categoryID"].ToString()),
                        Convert.ToString(read["description"].ToString())
                    );
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return category;
        }

        public void Update(CategoryModel category)
        {
            try
            {
                SqlCommand command = null;
                
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementCategories, "Categories");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = category.CategoryID;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = category.Description;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeUpdate;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }
    }
}
