﻿using System;
using System.Collections.Generic;
using ProductManagement.DataAccess.Interface;
using ProductManagement.Entities.Models;
using System.Data.SqlClient;
using System.Data;

namespace ProductManagement.DataAccess.DAO
{
    public class ClientDAO : DataBaseConnection, IDao<ClientModel>
    {
        public void Create(ClientModel client)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementClients, "Clients");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@clientID", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = client.Name;
                command.Parameters.Add("@address", SqlDbType.VarChar).Value = client.Address;
                command.Parameters.Add("@phone", SqlDbType.VarChar).Value = client.Phone;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeInsert;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public void Delete(ClientModel client)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementClients, "Clients");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@clientID", SqlDbType.Int).Value = client.ClientID;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = client.Name;
                command.Parameters.Add("@address", SqlDbType.VarChar).Value = client.Address;
                command.Parameters.Add("@phone", SqlDbType.VarChar).Value = client.Phone;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeDelete;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public List<ClientModel> FindAll()
        {
            List<ClientModel> clients = new List<ClientModel>();

            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementClients, "Clients");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@clientID", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@address", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@phone", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelect;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    ClientModel client = new ClientModel
                    (
                        Convert.ToInt32(read["clientID"].ToString()),
                        Convert.ToString(read["name"].ToString()),
                        Convert.ToString(read["address"].ToString()),
                        Convert.ToString(read["phone"].ToString())
                    );

                    clients.Add(client);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return clients;
        }

        public ClientModel FindID(int ID)
        {
            ClientModel client = new ClientModel();

            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementClients, "Categories");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@clientID", SqlDbType.Int).Value = ID;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@address", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@phone", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelectID;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    client = new ClientModel
                    (
                        Convert.ToInt32(read["clientID"].ToString()),
                        Convert.ToString(read["name"].ToString()),
                        Convert.ToString(read["address"].ToString()),
                        Convert.ToString(read["phone"].ToString())
                    );
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return client;
        }

        public void Update(ClientModel client)
        {
            try
            {
                SqlCommand command = null;
                
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementClients, "Clients");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@clientID", SqlDbType.Int).Value = client.ClientID;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = client.Name;
                command.Parameters.Add("@address", SqlDbType.VarChar).Value = client.Address;
                command.Parameters.Add("@phone", SqlDbType.VarChar).Value = client.Phone;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeUpdate;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }
    }
}
