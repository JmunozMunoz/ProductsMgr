﻿using System;
using System.Collections.Generic;
using ProductManagement.DataAccess.Interface;
using ProductManagement.Entities.Models;
using System.Data.SqlClient;
using System.Data;

namespace ProductManagement.DataAccess.DAO
{
    public class ProductDAO : DataBaseConnection, IDao<ProductModel>
    {
        public void Create(ProductModel product)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProducts, "Products");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = product.Name;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = product.Description;
                command.Parameters.Add("@price", SqlDbType.Decimal).Value = product.Price;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeInsert;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public void Delete(ProductModel product)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProducts, "Products");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = product.ProductID;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = product.Name;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = product.Description;
                command.Parameters.Add("@price", SqlDbType.Decimal).Value = product.Price;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeDelete;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public List<ProductModel> FindAll()
        {
            List<ProductModel> products = new List<ProductModel>();

            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProducts, "Products");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = 1;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@price", SqlDbType.Decimal).Value = 1;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelect;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    ProductModel product = new ProductModel
                    (
                        Convert.ToInt32(read["productID"].ToString()),
                        Convert.ToString(read["name"].ToString()),
                        Convert.ToString(read["description"].ToString()),
                        Convert.ToDecimal(read["price"].ToString())
                    );

                    products.Add(product);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return products;
        }

        public ProductModel FindID(int ID)
        {
            ProductModel product = new ProductModel();

            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProducts, "Products");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = ID;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = "-";
                command.Parameters.Add("@price", SqlDbType.Decimal).Value = 1;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelectID;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    product = new ProductModel
                    (
                        Convert.ToInt32(read["productID"].ToString()),
                        Convert.ToString(read["name"].ToString()),
                        Convert.ToString(read["description"].ToString()),
                        Convert.ToDecimal(read["price"].ToString())
                    );
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return product;
        }

        public void Update(ProductModel product)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProducts, "Products");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = product.ProductID;
                command.Parameters.Add("@name", SqlDbType.VarChar).Value = product.Name;
                command.Parameters.Add("@description", SqlDbType.VarChar).Value = product.Description;
                command.Parameters.Add("@price", SqlDbType.Decimal).Value = product.Price;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeUpdate;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }
    }
}
