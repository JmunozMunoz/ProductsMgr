﻿using System;
using System.Collections.Generic;
using ProductManagement.DataAccess.Interface;
using ProductManagement.Entities.Models;
using System.Data.SqlClient;
using System.Data;

namespace ProductManagement.DataAccess.DAO
{
    public class ProductCategoryDAO : DataBaseConnection
    {
        public void Create(ProductModel product, CategoryModel category)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProductCategory, "ProductCategory");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = product.ProductID;
                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = category.CategoryID;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeInsert;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public void Delete(ProductModel product, CategoryModel category)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProductCategory, "ProductCategory");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = (product == null)? -1 : product.ProductID;
                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = (category == null) ? -1 : category.CategoryID;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeDelete;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public List<CategoryModel> FindID(ProductModel product)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementProductCategory, "ProductCategory");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@productID", SqlDbType.Int).Value = product.ProductID;
                command.Parameters.Add("@categoryID", SqlDbType.Int).Value = -1;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelectID;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    CategoryModel category = new CategoryModel
                    (
                        Convert.ToInt32(read["categoryID"].ToString()),
                        Convert.ToString(read["description"].ToString()),
                        product
                    );
                    product.CategoriesModel.Add(category);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return product.CategoriesModel;
        }
    }
}
