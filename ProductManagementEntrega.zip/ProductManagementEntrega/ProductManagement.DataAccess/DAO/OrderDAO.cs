﻿using System;
using System.Collections.Generic;
using ProductManagement.DataAccess.Interface;
using ProductManagement.Entities.Models;
using System.Data.SqlClient;
using System.Data;

namespace ProductManagement.DataAccess.DAO
{
    public class OrderDAO : DataBaseConnection
    {
        public void Create(ProductModel product, ClientModel client, OrderModel order)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementOrders, "Orders");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@orderID", SqlDbType.Int).Value = (order == null) ? -1 : order.OrderID;
                command.Parameters.Add("@productID", SqlDbType.Int).Value = (product == null)? -1 : product.ProductID;
                command.Parameters.Add("@clientID", SqlDbType.Int).Value = (client == null) ? -1 : client.ClientID;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeInsert;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public void Delete(int orderID, ProductModel product, ClientModel client)
        {
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementOrders, "Orders");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@orderID", SqlDbType.Int).Value = orderID;
                command.Parameters.Add("@productID", SqlDbType.Int).Value = (product == null)? -1 : product.ProductID;
                command.Parameters.Add("@clientID", SqlDbType.Int).Value = (client == null) ? -1 : client.ClientID;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeDelete;

                this.OpenConnection();
                command.ExecuteNonQuery();
            }
            catch
            {
            }
            finally
            {
                this.CloseConnection();
            }
        }

        public OrderModel FindID(int orderID)
        {
            OrderModel order = null;
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementOrders, "Orders");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@orderID", SqlDbType.Int).Value = orderID;
                command.Parameters.Add("@productID", SqlDbType.Int).Value = -1;
                command.Parameters.Add("@clientID", SqlDbType.Int).Value = -1;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelectID;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    if (order == null)
                    {
                        order = new OrderModel
                        (
                            Convert.ToInt32(read["orderID"].ToString()),
                            Convert.ToDateTime(read["registerDate"].ToString()),
                            null
                        );

                        ClientDAO clientDAO = new ClientDAO();
                        order.ClientModel = clientDAO.FindID(Convert.ToInt32(read["cientID"].ToString()));
                    }

                    if (!string.IsNullOrEmpty(read["productID"].ToString()))
                    {
                        ProductModel productModel = new ProductModel
                        (
                            Convert.ToInt32(read["productID"].ToString()),
                            Convert.ToString(read["name"].ToString()),
                            Convert.ToString(read["description"].ToString()),
                            Convert.ToDecimal(read["price"].ToString())
                        );
                        order.ProductsModel.Add(productModel);
                    }

                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return order;
        }
        
        public List<OrderModel> Find(ClientModel client)
        {
            List<OrderModel> orders = new List<OrderModel>();
            try
            {
                SqlCommand command = null;
                string storedprocedure = this.GetConfigParameter(Constants.ApiName_MangementOrders, "Orders");

                command = DataBaseConnection.GetStoredProcedure(this.Connection, storedprocedure);

                command.Parameters.Add("@orderID", SqlDbType.Int).Value = -1;
                command.Parameters.Add("@productID", SqlDbType.Int).Value = -1;
                command.Parameters.Add("@clientID", SqlDbType.Int).Value = client.ClientID;
                command.Parameters.Add("@StatementType", SqlDbType.VarChar).Value = Constants.StatementTypeSelect;

                this.OpenConnection();
                SqlDataReader read = command.ExecuteReader();
                while (read.Read())
                {
                    OrderModel order = client.ExistsOrder(Convert.ToInt32(read["orderID"].ToString()));
                    if (order == null) {
                        order = new OrderModel
                        (
                            Convert.ToInt32(read["orderID"].ToString()),
                            Convert.ToDateTime(read["registerDate"].ToString()),
                            client
                        );
                        client.OrdersModel.Add(order);
                        orders.Add(order);
                    }

                    if (!string.IsNullOrEmpty(read["productID"].ToString()))
                    {
                        ProductModel productModel = new ProductModel
                        (
                            Convert.ToInt32(read["productID"].ToString()),
                            Convert.ToString(read["name"].ToString()),
                            Convert.ToString(read["description"].ToString()),
                            Convert.ToDecimal(read["price"].ToString())
                        );
                        order.ProductsModel.Add(productModel);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                this.CloseConnection();
            }

            return orders;
        }
    }
}
