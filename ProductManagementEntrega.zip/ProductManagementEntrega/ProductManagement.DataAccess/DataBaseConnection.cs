﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.DataAccess
{
    /// <summary>
    /// Data Base Conection
    /// </summary>
    public partial class DataBaseConnection
    {
        #region Properties
        /// <summary>
        /// Connection to SQL Server
        /// </summary>
        private static SqlConnection _connection = null;

        public SqlConnection Connection
        {
            get { return _connection; }
        }
        #endregion

        #region Contructor
        /// <summary>
        /// Contructor DataBaseConnection
        /// </summary>
        public DataBaseConnection()
        {
            string stringconnection = ValidateConnectionStringsParameter(Constants.ConnectionStrings);
            _connection = new SqlConnection(stringconnection);
        }
        #endregion

        #region Methods
        /// <summary>
        /// Open Connection to SQL Server
        /// </summary>
        /// <returns>Connection</returns>
        public SqlConnection OpenConnection()
        {
            if (_connection.State == ConnectionState.Closed) _connection.Open();
            return _connection;
        }

        /// <summary>
        /// Close the connection
        /// </summary>
        public void CloseConnection()
        {
            if (_connection != null) _connection.Close();
        }

        /// <summary>
        /// Get the Connection String to configurate Web.Config
        /// </summary>
        /// <param name="connectionString">Connection String</param>
        /// <returns></returns>
        public string ValidateConnectionStringsParameter(string connectionString)
        {
            string storedprocedure = GetConnectionStringParameter(connectionString);
            if (storedprocedure == null)
            {
                string msg = "ConnectionString Key \"" + connectionString + "\" no definida en el archivo config (web o app)";
                throw new Exception(msg);
            }
            return storedprocedure;
        }

        /// <summary>
        /// Get the Connection String to configurate Web.Config
        /// </summary>
        /// <param name="connectionString">Connection String</param>
        /// <returns></returns>
        private static string GetConnectionStringParameter(string connectionString)
        {
            ConnectionStringSettings css = ConfigurationManager.ConnectionStrings[connectionString];
            if (css != null)
                return css.ConnectionString;
            else
                return null;
        }

        /// <summary>
        /// GetConfigParameter 
        /// </summary>
        /// <param name="parameter"></param>
        /// <param name="nombreServicio"></param>
        /// <returns></returns>
        public string GetConfigParameter(string parameter, string nombreServicio)
        {
            if (parameter == null)
            {
                throw new ArgumentException("Error pasando parámetro de configuración nulo en el appSettings del archivo config (web o app). Servicio :" + nombreServicio, parameter);
            }

            string value = ConfigurationManager.AppSettings.Get(parameter);
            if (value == null)
            {
                string osbMensajeError = "Key [" + parameter + "] no definida en el appSettings del archivo config (web o app) para el Servicio: " + nombreServicio;
                throw new ArgumentException(osbMensajeError);
            }
            return value;
        }


        /// <summary>
        /// Crea un dbcommand de tipo storedprocedure usando el nombre del paquete con el nombre del comando - LFM
        /// </summary>
        /// <param name="connection"></param>
        /// <param name="CommandText"></param>
        /// <returns></returns>
        public static SqlCommand GetStoredProcedure(SqlConnection connection, string CommandText)
        {
            SqlCommand command = new SqlCommand(CommandText, connection)
            {
                CommandType = CommandType.StoredProcedure,
                CommandText = CommandText
            };

            return command;
        }
        #endregion
    }
}
