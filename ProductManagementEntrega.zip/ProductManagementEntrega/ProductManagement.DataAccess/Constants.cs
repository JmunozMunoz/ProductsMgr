﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.DataAccess
{
    public class Constants
    {
        /// <summary>
        ///  Define Name connectionStrings
        /// </summary>
        public const string ConnectionStrings = "SQL_ConnectionString";
        public const string StatementTypeInsert = "Insert";
        public const string StatementTypeSelect = "Select";
        public const string StatementTypeUpdate = "Update";
        public const string StatementTypeDelete = "Delete";
        public const string StatementTypeSelectID = "SelectID";

        //
        public const string ApiName_MangementProducts = "ApiName_MangementProducts";
        public const string ApiName_MangementCategories = "ApiName_MangementCategories";
        public const string ApiName_MangementClients = "ApiName_MangementClients";
        public const string ApiName_MangementProductCategory = "ApiName_MangementProductCategory";
        public const string ApiName_MangementOrders = "ApiName_MangementOrders";
    }
}
