﻿using System.Web.Mvc;
using System.Collections.Generic;
using System;
using ProductManagement.BussinessLogical;
using ProductManagement.Entities.Models;
using Microsoft.Extensions.Caching.Memory;

namespace ProductManagement.Controllers
{
    public class ProductController : Controller
    {
        private ProductBL productBL = new ProductBL();
        private CategoryBL categoryBL = new CategoryBL();

        /// <summary>
        /// Key to List Products
        /// </summary>
        private const string keyProduct = "Products";
        private string isCache = "false";
        private IMemoryCache cache;

        public ProductController()
        {
        }

        public ProductController(IMemoryCache memoryCache)
        {
            this.cache = memoryCache;
        }


        // GET: Product
        public ActionResult Index()
        {
            isCache = (Session["_SaveInMemory"] == null) ? "False" : Session["_SaveInMemory"].ToString();

            List<ProductModel> lstProducts = GetProducts();

            return View(lstProducts);
        }

        private List<ProductModel> GetProducts()
        {
            List<ProductModel> listProducts;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyProduct, out listProducts))
                {
                    listProducts = productBL.FindAll();
                    AddProductsCache(listProducts);
                }
            }
            else
            {
                listProducts = productBL.FindAll(); ;
            }
            return listProducts;
        }
        private void AddProductsCache(List<ProductModel> listProducts)
        {
            var optionCache = new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now.AddMinutes(60)
            };
            this.cache.Set<List<ProductModel>>(keyProduct, listProducts, optionCache);
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(ProductModel model)
        {
            try
            {
                //Valid the DataAnnotations
                if (ModelState.IsValid)
                {
                    CreateProduct(model);

                    return RedirectToAction("Index");
                }
                return View(model);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void CreateProduct(ProductModel model)
        {
            List<ProductModel> listProduct;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyProduct, out listProduct))
                {
                    listProduct.Add(model);
                    AddProductsCache(listProduct);
                }
            }
            else
            {
                productBL.Create(model);
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
            ProductModel model = productBL.FindID(id);

            return View(model);
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(ProductModel model)
        {
            try
            {
                //Valid the DataAnnotations
                if (ModelState.IsValid)
                {
                    UpdateProduct(model);

                    return RedirectToAction("Index");
                }
                return View(model);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void UpdateProduct(ProductModel model)
        {
            List<ProductModel> listProduct;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyProduct, out listProduct))
                {
                    foreach (ProductModel product in listProduct)
                    {
                        if (product.ProductID == model.ProductID)
                        {
                            product.Name = model.Name;
                            product.Description = model.Description;
                            product.Price = model.Price;
                        }
                    }

                    AddProductsCache(listProduct);
                }
            }
            else
            {
                productBL.Update(model);
            }
        }

        // GET: Product/Delete/5
        [HttpGet]
        public ActionResult Delete(int id)
        {
            ProductModel model = productBL.FindID(id);
            DeleteProduct(model);

            return RedirectToAction("Index");
        }

        private void DeleteProduct(ProductModel model)
        {
            List<ProductModel> listProduct;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyProduct, out listProduct))
                {
                    listProduct.Remove(model);

                    AddProductsCache(listProduct);
                }
            }
            else
            {
                productBL.Delete(model);
            }
        }

        // GET: Product/DeleteCategory/6
        [HttpGet()]
        public ActionResult DeleteCategory(int productID, int categoryID)
        {
            productBL.DeleteCategory(productID, categoryID);

            return RedirectToAction("Details", new { id = productID });
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            ProductModel model = productBL.FindID(id);

            ViewBag._ListCategories = new SelectList(categoryBL.FindAll(), "CategoryID", "Description");

            return View(model);
        }

        // POST: Product/Details/5
        [HttpPost]
        public ActionResult Details(ProductModel model)
        {
            try
            {
                if (!String.IsNullOrEmpty(model.CategoryID))
                {
                    ProductModel productModel = productBL.FindID(model.ProductID);
                    CategoryModel categoryModel = categoryBL.FindID(Convert.ToInt32(model.CategoryID));

                    productBL.CreateProductCategory(productModel, categoryModel);

                    return RedirectToAction("Details", new { id = model.ProductID });
                }
                return RedirectToAction("Details", new { id = model.ProductID });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
