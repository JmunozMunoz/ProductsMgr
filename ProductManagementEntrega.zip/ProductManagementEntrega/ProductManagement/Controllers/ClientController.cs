﻿using System.Web.Mvc;
using System.Collections.Generic;
using System;
using ProductManagement.BussinessLogical;
using ProductManagement.Entities.Models;
using Microsoft.Extensions.Caching.Memory;

namespace ProductManagement.Controllers
{
    public class ClientController : Controller
    {
        private ClientBL clientBL = new ClientBL();
        private ProductBL productBL = new ProductBL();
        
        /// <summary>
        /// Key to List Clients
        /// </summary>
        private const string keyClient = "Clients";
        private string isCache = "false";
        private IMemoryCache cache;

        public ClientController()
        {
        }

        public ClientController(IMemoryCache memoryCache)
        {
            this.cache = memoryCache;
        }

        // GET: Product
        public ActionResult Index()
        {
            isCache = (Session["_SaveInMemory"] == null) ? "False" : Session["_SaveInMemory"].ToString();

            List<ClientModel> lstClients = this.GetClients();

            return View(lstClients);
        }

        /// <summary>
        /// Get Clients if cache or no cache
        /// </summary>
        /// <returns></returns>
        private List<ClientModel> GetClients()
        {
            List<ClientModel> listClient;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyClient, out listClient))
                {
                    listClient = clientBL.FindAll();
                    AddClientsCache(listClient);
                }
            }
            else
            {
                listClient = clientBL.FindAll();
            }
            return listClient;
        }

        private void AddClientsCache(List<ClientModel> listClients)
        {
            var optionCache = new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now.AddMinutes(60)
            };
            this.cache.Set<List<ClientModel>>(keyClient, listClients, optionCache);
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(ClientModel model)
        {
            try
            {
                //Valid the DataAnnotations
                if (ModelState.IsValid)
                {
                    this.CreateClient(model);

                    return RedirectToAction("Index");
                }
                return View(model);
            }
            catch(Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void CreateClient(ClientModel model)
        {
            List<ClientModel> listClient;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyClient, out listClient))
                {
                    listClient.Add(model);
                    AddClientsCache(listClient);
                }
            }
            else
            {
                clientBL.Create(model);
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
            ClientModel model = clientBL.FindID(id);

            return View(model);
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(ClientModel model)
        {
            try
            {
                //Valid the DataAnnotations
                if (ModelState.IsValid)
                {
                    UpdateClient(model);

                    return RedirectToAction("Index");
                }
                return View(model);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void UpdateClient(ClientModel model)
        {
            List<ClientModel> listClient;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyClient, out listClient))
                {
                    foreach (ClientModel client  in listClient)
                    {
                        if (client.ClientID == model.ClientID)
                        {
                            client.Address = model.Address;
                            client.Name = model.Name;
                            client.Phone = model.Phone;
                        }
                    }

                    AddClientsCache(listClient);
                }
            }
            else
            {
                clientBL.Update(model);
            }
        }

        // GET: Product/Delete/5
        [HttpGet]
        public ActionResult Delete(int id)
        {
            ClientModel model = clientBL.FindID(id);
            DeleteClient(model);

            return RedirectToAction("Index");
        }

        private void DeleteClient(ClientModel model)
        {
            List<ClientModel> listClient;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyClient, out listClient))
                {
                    listClient.Remove(model);

                    AddClientsCache(listClient);
                }
            }
            else
            {
                clientBL.Delete(model);
            }
        }

        // GET: Product/DeleteCategory/6
        [HttpGet]
        public ActionResult DeleteOrder(int orderID, int clientID)
        {
            clientBL.DeleteOrder(orderID);

            return RedirectToAction("Details", new { id = clientID });
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            ClientModel model = clientBL.FindID(id);

            return View(model);
        }
        
        // GET: Product/OrdersDetails/5
        public ActionResult OrdersDetails(int id)
        {
            OrderModel model = clientBL.FindOrderID(id);

            ViewBag._ListProducts = new SelectList(productBL.FindAll(), "ProductID", "Name");

            return View(model);
        }

        // POST: Product/OrdersDetails/5
        [HttpPost]
        public ActionResult OrdersDetails(OrderModel model)
        {
            try
            {
                if (!String.IsNullOrEmpty(model.ProductID))
                {
                    OrderModel orderModel = clientBL.FindOrderID(model.OrderID);
                    ProductModel productModel = productBL.FindID(Convert.ToInt32(model.ProductID));

                    clientBL.CreateOrder(productModel, null, orderModel);

                    return RedirectToAction("OrdersDetails", new { id = model.OrderID });
                }
                return RedirectToAction("OrdersDetails", new { id = model.OrderID });
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        // GET: Product/DeleteCategory/6
        [HttpGet]
        public ActionResult DeleteOrderProduct(int orderID, int productID)
        {
            clientBL.DeleteOrderProduct(orderID, productID);

            return RedirectToAction("OrdersDetails", new { id = orderID });
        }

        // GET: Product/DeleteCategory/6
        [HttpGet]
        public ActionResult CreateOrder(int id)
        {
            ClientModel model = clientBL.FindID(id);
            clientBL.CreateOrder(null, model, null);

            return RedirectToAction("Details", new { id = model.ClientID });
        }
    }
}
