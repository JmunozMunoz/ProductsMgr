﻿using Microsoft.Extensions.Caching.Memory;
using ProductManagement.BussinessLogical;
using ProductManagement.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ProductManagement.Controllers
{
    public class CategoryController : Controller
    {
        private CategoryBL categoryBL = new CategoryBL();

        /// <summary>
        /// Key to List Clients
        /// </summary>
        private const string keyCategory = "Categories";
        private string isCache = "false";
        private IMemoryCache cache;

        public CategoryController()
        {
        }

        public CategoryController(IMemoryCache memoryCache)
        {
            this.cache = memoryCache;
        }

        // GET: Product
        public ActionResult Index()
        {
            isCache = (Session["_SaveInMemory"] == null) ? "False" : Session["_SaveInMemory"].ToString();
            List<CategoryModel> lstCategories = GetCategories();

            return View(lstCategories);
        }

        private List<CategoryModel> GetCategories()
        {

            List<CategoryModel> listCategories;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyCategory, out listCategories))
                {
                    listCategories = categoryBL.FindAll();
                    AddCategoriesCache(listCategories);
                }
            }
            else
            {
                listCategories = categoryBL.FindAll();
            }
            return listCategories;
        }

        private void AddCategoriesCache(List<CategoryModel> listCategories)
        {
            var optionCache = new MemoryCacheEntryOptions
            {
                AbsoluteExpiration = DateTime.Now.AddMinutes(60)
            };
            this.cache.Set<List<CategoryModel>>(keyCategory, listCategories, optionCache);
        }

        // GET: Product/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Product/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Product/Create
        [HttpPost]
        public ActionResult Create(CategoryModel model)
        {
            try
            {
                //Valid the DataAnnotations
                if (ModelState.IsValid)
                {
                    CreateCategory(model);

                    return RedirectToAction("Index");
                }
                return View(model);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void CreateCategory(CategoryModel model)
        {
            List<CategoryModel> listCategories;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyCategory, out listCategories))
                {
                    listCategories.Add(model);
                    AddCategoriesCache(listCategories);
                }
            }
            else
            {
                categoryBL.Create(model);
            }
        }

        // GET: Product/Edit/5
        public ActionResult Edit(int id)
        {
            CategoryModel model = categoryBL.FindID(id);

            return View(model);
        }

        // POST: Product/Edit/5
        [HttpPost]
        public ActionResult Edit(CategoryModel model)
        {
            try
            {
                //Valid the DataAnnotations
                if (ModelState.IsValid)
                {
                    UpdateCategory(model);

                    return RedirectToAction("Index");
                }
                return View(model);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private void UpdateCategory(CategoryModel model)
        {
            List<CategoryModel> listCategories;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyCategory, out listCategories))
                {
                    foreach (CategoryModel category in listCategories)
                    {
                        if (category.CategoryID == model.CategoryID)
                        {
                            category.Description = model.Description;
                        }
                    }

                    AddCategoriesCache(listCategories);
                }
            }
            else
            {
                categoryBL.Update(model);
            }
        }

        // GET: Product/Delete/5
        [HttpGet]
        public ActionResult Delete(int id)
        {
            CategoryModel model = categoryBL.FindID(id);
            DeleteCategory(model);

            return RedirectToAction("Index");
        }

        private void DeleteCategory(CategoryModel model)
        {
            List<CategoryModel> listCategory;
            if (isCache.ToUpper() == "TRUE")
            {
                if (!this.cache.TryGetValue(keyCategory, out listCategory))
                {
                    listCategory.Remove(model);

                    AddCategoriesCache(listCategory);
                }
            }
            else
            {
                categoryBL.Delete(model);
            }
        }
    }
}