﻿using ProductManagement.DataAccess.DAO;
using ProductManagement.Entities.Models;
using System.Collections.Generic;

namespace ProductManagement.BussinessLogical
{
    public class ClientBL
    {
        private ClientDAO clientDAO = new ClientDAO();
        private OrderDAO orderDAO = new OrderDAO();
        private ProductDAO productDAO = new ProductDAO();

        public void Create(ClientModel client)
        {
            clientDAO.Create(client);
        }

        public void Update(ClientModel client)
        {
            clientDAO.Update(client);
        }

        public void Delete(ClientModel client)
        {
            orderDAO.Delete(-1, null, client);
            clientDAO.Delete(client);
        }

        public List<ClientModel> FindAll()
        {
            return clientDAO.FindAll();
        }

        public ClientModel FindID(int ID)
        {
            //Load the Orders by Client
            ClientModel client = clientDAO.FindID(ID);
            orderDAO.Find(client);

            return client;
        }

        public OrderModel FindOrderID(int ID)
        {
            OrderModel model = orderDAO.FindID(ID);
            return model;
        }

        public void DeleteOrder(int orderID)
        {
            orderDAO.Delete(orderID, null, null);
        }

        public void DeleteOrderProduct(int orderID, int productID)
        {
            ProductModel product = productDAO.FindID(productID);
            orderDAO.Delete(orderID, product, null);
        }

        public void CreateOrder(ProductModel product, ClientModel client, OrderModel order)
        {
            orderDAO.Create(product, client, order);
        }
    }
}
