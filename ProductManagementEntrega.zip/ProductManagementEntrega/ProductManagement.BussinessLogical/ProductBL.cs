﻿using ProductManagement.DataAccess.DAO;
using ProductManagement.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.BussinessLogical
{
    public class ProductBL
    {
        private ProductDAO productDAO = new ProductDAO();
        private CategoryDAO categoryDAO = new CategoryDAO();
        private OrderDAO orderDAO = new OrderDAO();
        private ProductCategoryDAO productCategoryDAO = new ProductCategoryDAO();

        public void Create(ProductModel product)
        {
            productDAO.Create(product);
        }
        public void CreateProductCategory(ProductModel product, CategoryModel category)
        {
            productCategoryDAO.Create(product, category);
            product.CategoriesModel.Add(category);
            category.ProductsModel.Add(product);
        }

        public void Update(ProductModel product)
        {
            productDAO.Update(product);
        }

        public void Delete(ProductModel product)
        {
            productCategoryDAO.Delete(product, null);
            orderDAO.Delete(-1, product, null);
            productDAO.Delete(product);
        }

        public List<ProductModel> FindAll()
        {
            return productDAO.FindAll();
        }

        public ProductModel FindID(int ID)
        {
            ProductModel product = productDAO.FindID(ID);
            productCategoryDAO.FindID(product);
            return product;
        }

        public ProductModel DeleteCategory(int prductID, int categoryID)
        {
            ProductModel product = productDAO.FindID(prductID);
            CategoryModel category = categoryDAO.FindID(categoryID);
            productCategoryDAO.Delete(product, category);
            return product;
        }
    }
}
