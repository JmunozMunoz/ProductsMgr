﻿using ProductManagement.DataAccess.DAO;
using ProductManagement.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.BussinessLogical
{
    public class CategoryBL
    {
        private CategoryDAO categoryDAO = new CategoryDAO();
        private ProductCategoryDAO productCategoryDAO = new ProductCategoryDAO();

        public void Create(CategoryModel category)
        {
            categoryDAO.Create(category);
        }

        public void Update(CategoryModel category)
        {
            categoryDAO.Update(category);
        }

        public void Delete(CategoryModel category)
        {
            categoryDAO.Delete(category);
            productCategoryDAO.Delete(null, category);
        }

        public List<CategoryModel> FindAll()
        {
            return categoryDAO.FindAll();
        }

        public CategoryModel FindID(int ID)
        {
            return categoryDAO.FindID(ID);
        }
    }
}
