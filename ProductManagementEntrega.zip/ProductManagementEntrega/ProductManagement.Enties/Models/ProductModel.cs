﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace ProductManagement.Entities.Models
{
    public class ProductModel
    {
        #region Properties
        /// <summary>
        /// List Categories
        /// </summary>
        public List<CategoryModel> CategoriesModel { get; set; }
        /// <summary>
        /// List Orders
        /// </summary>
        public List<OrderModel> OrdersModel { get; set; }
        /// <summary>
        /// Product Code
        /// </summary>
        public int ProductID { get; set; }
        /// <summary>
        /// Name Product
        /// </summary>
        [Required]
        [StringLength(50)]
        [Display(Name = "Name")]
        public string Name { get; set; }
        /// <summary>
        /// Desctription Product
        /// </summary>        
        [Required]
        [StringLength(100)]
        [Display(Name = "Description")]
        public string Description { get; set; }
        /// <summary>
        /// Price Product Dolars
        /// </summary>
        [Required]
        [DataType(DataType.Currency)]
        [Display(Name = "Price")]
        public decimal Price { get; set; }

        /// <summary>
        /// Product Code
        /// </summary>
        [Display(Name = "Select Category")]
        public string CategoryID { get; set; }
        #endregion

        #region Constructor
        public ProductModel()
        {
            CategoriesModel = new List<CategoryModel>();
            OrdersModel = new List<OrderModel>();
        }

        public ProductModel(int productID, string name, string description, decimal price)
            : this()
        {
            this.ProductID = productID;
            this.Name = name;
            this.Description = description;
            this.Price = price;
        }
        #endregion
    }
}
