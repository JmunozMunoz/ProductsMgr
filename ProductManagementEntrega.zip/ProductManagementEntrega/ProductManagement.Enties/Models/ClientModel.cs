﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.Entities.Models
{
    public class ClientModel
    {
        #region Properties
        /// <summary>
        /// List Orders
        /// </summary>
        public List<OrderModel> OrdersModel { get; set; }
        /// <summary>
        /// Client Code
        /// </summary>
        public int ClientID { get; set; }
        /// <summary>
        /// Client Name
        /// </summary>        
        [Required]
        [StringLength(100)]
        [Display(Name = "Nombre")]
        public string Name { get; set; }
        /// <summary>
        /// Address Client
        /// </summary>        
        [Required]
        [StringLength(100)]
        [Display(Name = "Address")]
        public string Address { get; set; }
        /// <summary>
        /// Phone Client
        /// </summary>        
        [Required]
        [StringLength(100)]
        [Display(Name = "Phone")]
        public string Phone { get; set; }
        #endregion

        #region Constructor
        public ClientModel()
        {
            OrdersModel = new List<OrderModel>();
        }

        public ClientModel(int clientID, string name, string address, string phone)
            : this()
        {
            this.ClientID = clientID;
            this.Name = name;
            this.Address = address;
            this.Phone = phone;
        }

        public OrderModel ExistsOrder(int orderID)
        {
            foreach (OrderModel item in OrdersModel)
            {
                if (item.OrderID == orderID)
                    return item;
            }
            return null;
        }
        #endregion
    }
}
