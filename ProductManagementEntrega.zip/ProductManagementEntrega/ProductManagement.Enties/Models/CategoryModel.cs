﻿
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ProductManagement.Entities.Models
{
    public class CategoryModel
    {
        #region Properties
        public List<ProductModel> ProductsModel { get; set; }
        /// <summary>
        /// Category Code
        /// </summary>
        public int CategoryID { get; set; }
        /// <summary>
        /// Desctription Product
        /// </summary>        
        [Required]
        [StringLength(100)]
        [Display(Name = "Description")]
        public string Description { get; set; }
        #endregion

        #region Constructor
        public CategoryModel()
        {
            ProductsModel = new List<ProductModel>();
        }

        public CategoryModel(int categoryID, string description)
            : this()
        {
            this.CategoryID = categoryID;
            this.Description = description;
        }

        public CategoryModel(int categoryID, string description, ProductModel product)
            : this()
        {
            this.CategoryID = categoryID;
            this.Description = description;
            ProductsModel.Add(product);
        }
        #endregion
    }
}