﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductManagement.Entities.Models
{
    public class OrderModel
    {
        #region Properties
        public int OrderID { get; set; }
        /// <summary>
        /// List Products
        /// </summary>
        public List<ProductModel> ProductsModel { get; set; }
        /// <summary>
        /// Client
        /// </summary>
        public ClientModel ClientModel { get; set; }
        /// <summary>
        /// Category Code
        /// </summary>
        public DateTime RegisterDate { get; set; }
        /// <summary>
        /// Product Code
        /// </summary>
        [Display(Name = "Select Product")]
        public string ProductID { get; set; }
        #endregion

        #region Constructor
        public OrderModel()
        {
            ProductsModel = new List<ProductModel>();
            ClientModel = new ClientModel();
            ProductID = string.Empty;
        }

        public OrderModel(int orderID, DateTime registerDate)
            : this()
        {
            this.OrderID = orderID;
            this.RegisterDate = registerDate;
        }

        public OrderModel(int orderID, DateTime registerDate, ClientModel clientModel)
            : this(orderID, registerDate)
        {
            this.ClientModel = clientModel;
        }
        #endregion
    }
}
